"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Box, Typography, Card, CardMedia, CardContent, Button } from "@mui/material";

const vehiclesData = [
  { id: 1, make: "BYD", model: "Dolphin", year: 2022, price: 50, image: "https://www.byd.com/content/dam/byd-site/eu/electric-cars/dolphin/xl/Dolphin-exterior-04-SkiingwhiteUrbangrey-xl.jpg", details: "Electric car with 300 miles range." },
  { id: 2, make: "Tesla", model: "Model S", year: 2021, price: 45, image: "https://static1.topspeedimages.com/wordpress/wp-content/uploads/2023/06/tesla-model-s-plaid-2.jpg", details: "Luxury electric sedan with autopilot." },
  { id: 3, make: "Tesla", model: "Model 3", year: 2020, price: 40, image: "https://www.tesla.com/ownersmanual/images/GUID-B5641257-9E85-404B-9667-4DA5FDF6D2E7-online-en-US.png", details: "Affordable Tesla with high efficiency." },
  { id: 4, make: "Tesla", model: "Model X", year: 2023, price: 70, image: "https://images.prismic.io/carwow/c340a77d-af56-4562-abfb-bd5518ccb292_2023+Tesla+Model+X+front+quarter+moving.jpg", details: "Spacious electric SUV with Falcon doors." },
  { id: 5, make: "Tesla", model: "Model Y", year: 2022, price: 80, image: "https://images.hgmsites.net/lrg/2022-tesla-model-y-performance-awd-angular-front-exterior-view_100833533_l.jpg", details: "Compact SUV with advanced technology." },
];

const VehicleList = () => {
  const router = useRouter();
  const [vehicles, setVehicles] = useState([]);

  // Load vehicle data
  useEffect(() => {
    setVehicles(vehiclesData);
  }, []);

  return (
    <Box sx={{ p: 4, textAlign: "center", backgroundColor: "#f5f5f5" }}>
      <Typography variant="h3" sx={{ fontWeight: "bold", mb: 4 }}>Choose Your Vehicle</Typography>
      <Box sx={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 4 }}>
        {vehicles.map((vehicle) => (
          <Card key={vehicle.id} sx={{ maxWidth: 345, mx: "auto", boxShadow: 3 }}>
            <CardMedia
              component="img"
              height="200"
              image={vehicle.image}
              alt={`${vehicle.make} ${vehicle.model}`}
              sx={{ objectFit: "cover", cursor: "pointer" }}
              onClick={() => router.push(`/vehicle/${vehicle.id}`)} // ✅ Click to navigate
            />
            <CardContent>
              <Typography variant="h5" sx={{ fontWeight: "bold" }}>{vehicle.make} {vehicle.model}</Typography>
              <Typography variant="body1">Year: {vehicle.year}</Typography>
              <Typography variant="body1" color="primary">Price: ${vehicle.price}/day</Typography>
              <Button variant="contained" sx={{ mt: 2, width: "100%" }}>Rent Now</Button>
            </CardContent>
          </Card>
        ))}
      </Box>
    </Box>
  );
};

export default VehicleList;
